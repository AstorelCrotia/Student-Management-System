#include "head.h"

void winlottery(int *sc) // ��Ʊ����
{
    printf("====================================\n");
    printf("|  ��ѡ����Ҫ�����Ĳ�Ʊ��         |\n");
    printf("|                                |\n");
    printf("|  bbg�����롰1��                  |\n");
    printf("|                                |\n");
    printf("|  A�����롰2��                    |\n");
    printf("|                                |\n");
    printf("|  B�����롰3��                    |\n");
    printf("|                                |\n");
    printf("|  �˳�ϵͳ��������              |\n");
    printf("====================================\n");
    printf("������룺");
    scanf("%d", sc);
    switch (*sc)
    {
    case 1:
        winlotteryin1();
        break;
    case 2:
        winlotteryin2();
        break;
    case 3:
        winlotteryin3();
        break;
    default:
        break;
    }
}

void winlotteryin1() // ��Ʊ����д��1
{
    // int randomNum[6] = {0};
    // char randomStr[20] = "\0";
    // srand(time(NULL));
    // for (int i = 0; i < 6; i++)
    // {
    //     randomNum[i] = rand() % 100;
    // }
    // snprintf(randomStr, sizeof(randomStr), "%02d-%02d-%02d-%02d-%02d:%02d", randomNum[0], randomNum[1], randomNum[2], randomNum[3], randomNum[4], randomNum[5]);
    int randomNum[6] = {10,10,10,10,10,10};
    char randomStr[20] = "10-10-10-10-10:10";
    Lottery *head = NULL;
    Lottery lottery = {0};
    Lottery *current = (Lottery *)malloc(sizeof(Lottery));
    if (current == NULL)
    {
        printf("============================\n");
        printf("|  �ڴ����ʧ�ܣ�          |\n");
        printf("============================\n");
        return;
    }
    current->next = NULL;
    FILE *file_read = fopen("lottery1.txt", "r");
    if (file_read == NULL)
    {
        printf("============================\n");
        printf("|  ���ӷ�����ʧ�ܣ�        |\n");
        printf("============================\n");
        return;
    }
    while (fscanf(file_read, "��Ʊid��%s  �����û���%s  �ںţ�%s  ��Ʊ���ͣ�%d  �û����룺%s  �н����룺%s  �Ƿ񿪽���%d  �Ƿ��н���%d  �������ڣ�%s  �������ڣ�%s\n",
                  lottery.tid, lottery.uid, lottery.did, &lottery.category, lottery.usernumber, lottery.winnumber,
                  &lottery.draw, &lottery.win, lottery.buydate, lottery.windate) != EOF)
    {
        if (head == NULL)
        {
            head = current;
        }
        else
        {
            current->next = (Lottery *)malloc(sizeof(Lottery));
            if (current == NULL)
            {
                printf("============================\n");
                printf("|  �ڴ����ʧ�ܣ�          |\n");
                printf("============================\n");
                return;
            }
            current = current->next;
        }
        strcpy(current->tid, lottery.tid);
        strcpy(current->uid, lottery.uid);
        strcpy(current->did, lottery.did);
        current->category = lottery.category;
        strcpy(current->usernumber, lottery.usernumber);
        strcpy(current->winnumber, lottery.winnumber);
        current->draw = lottery.draw;
        current->win = lottery.win;
        strcpy(current->buydate, lottery.buydate);
        strcpy(current->windate, lottery.windate);
        current->next = NULL;
    }
    fclose(file_read);
    current = head;
    while (current != NULL)
    {
        InwinDate(current);
        current->draw = 1;
        strcpy(current->winnumber, randomStr);
        Prize(current, randomNum, 12);
        current = current->next;
    }
    FILE *file_write = fopen("lottery1.txt", "w");
    if (file_write == NULL)
    {
        printf("============================\n");
        printf("|  ���ӷ�����ʧ�ܣ�        |\n");
        printf("============================\n");
        return;
    }
    fclose(file_write);
    file_write = fopen("history.txt", "a");
    if (file_write == NULL)
    {
        printf("============================\n");
        printf("|  ���ӷ�����ʧ�ܣ�        |\n");
        printf("============================\n");
        return;
    }
    current = head;
    while (current != NULL)
    {
        fprintf(file_write, "��Ʊid��%s  �����û���%s  �ںţ�%s  ��Ʊ���ͣ�%d  �û����룺%s  �н����룺%s  �Ƿ񿪽���%d  �Ƿ��н���%d  �������ڣ�%s  �������ڣ�%s\n",
                current->tid, current->uid, current->did, current->category, current->usernumber, current->winnumber,
                current->draw, current->win, current->buydate, current->windate);
        current = current->next;
    }
    fclose(file_write);
    current = head;
    while (current != NULL)
    {
        Lottery *toFree = current;
        current = current->next;
        free(toFree);
    }
    head = NULL;
    printf("============================\n");
    printf("|  ����������            |\n");
    printf("============================\n");
}

void winlotteryin2() // ��Ʊ����д��2
{
    int randomNum[6] = {0};
    char randomStr[20] = "\0";
    srand(time(NULL));
    for (int i = 0; i < 6; i++)
    {
        randomNum[i] = rand() % 100;
    }
    snprintf(randomStr, sizeof(randomStr), "%02d-%02d-%02d-%02d-%02d:%02d", randomNum[0], randomNum[1], randomNum[2], randomNum[3], randomNum[4], randomNum[5]);
    Lottery *head = NULL;
    Lottery lottery = {0};
    Lottery *current = (Lottery *)malloc(sizeof(Lottery));
    if (current == NULL)
    {
        printf("============================\n");
        printf("|  �ڴ����ʧ�ܣ�          |\n");
        printf("============================\n");
        return;
    }
    current->next = NULL;
    FILE *file_read = fopen("lotter2.txt", "r");
    if (file_read == NULL)
    {
        printf("============================\n");
        printf("|  ���ӷ�����ʧ�ܣ�        |\n");
        printf("============================\n");
        return;
    }
    while (fscanf(file_read, "��Ʊid��%s  �����û���%s  �ںţ�%s  ��Ʊ���ͣ�%d  �û����룺%s  �н����룺%s  �Ƿ񿪽���%d  �Ƿ��н���%d  �������ڣ�%s  �������ڣ�%s\n",
                  lottery.tid, lottery.uid, lottery.did, &lottery.category, lottery.usernumber, lottery.winnumber,
                  &lottery.draw, &lottery.win, lottery.buydate, lottery.windate) != EOF)
    {
        if (head == NULL)
        {
            head = current;
        }
        else
        {
            current->next = (Lottery *)malloc(sizeof(Lottery));
            if (current == NULL)
            {
                printf("============================\n");
                printf("|  �ڴ����ʧ�ܣ�          |\n");
                printf("============================\n");
                return;
            }
            current = current->next;
        }
        strcpy(current->tid, lottery.tid);
        strcpy(current->uid, lottery.uid);
        strcpy(current->did, lottery.did);
        current->category = lottery.category;
        strcpy(current->usernumber, lottery.usernumber);
        strcpy(current->winnumber, lottery.winnumber);
        current->draw = lottery.draw;
        current->win = lottery.win;
        strcpy(current->buydate, lottery.buydate);
        strcpy(current->windate, lottery.windate);
        current->next = NULL;
    }
    fclose(file_read);
    current = head;
    while (current != NULL)
    {
        InwinDate(current);
        current->draw = 1;
        strcpy(current->winnumber, randomStr);
        Prize(current, randomNum, 12);
        current = current->next;
    }
    FILE *file_write = fopen("lottery2.txt", "w");
    if (file_write == NULL)
    {
        printf("============================\n");
        printf("|  ���ӷ�����ʧ�ܣ�        |\n");
        printf("============================\n");
        return;
    }
    fclose(file_write);
    file_write = fopen("history.txt", "a");
    if (file_write == NULL)
    {
        printf("============================\n");
        printf("|  ���ӷ�����ʧ�ܣ�        |\n");
        printf("============================\n");
        return;
    }
    current = head;
    while (current != NULL)
    {
        fprintf(file_write, "��Ʊid��%s  �����û���%s  �ںţ�%s  ��Ʊ���ͣ�%d  �û����룺%s  �н����룺%s  �Ƿ񿪽���%d  �Ƿ��н���%d  �������ڣ�%s  �������ڣ�%s\n",
                current->tid, current->uid, current->did, current->category, current->usernumber, current->winnumber,
                current->draw, current->win, current->buydate, current->windate);
        current = current->next;
    }
    fclose(file_write);
    current = head;
    while (current != NULL)
    {
        Lottery *toFree = current;
        current = current->next;
        free(toFree);
    }
    head = NULL;
    printf("============================\n");
    printf("|  ����������            |\n");
    printf("============================\n");
}

void winlotteryin3() // ��Ʊ����д��3
{
    int randomNum[6] = {0};
    char randomStr[20] = "\0";
    srand(time(NULL));
    for (int i = 0; i < 6; i++)
    {
        randomNum[i] = rand() % 100;
    }
    snprintf(randomStr, sizeof(randomStr), "%02d-%02d-%02d-%02d-%02d:%02d", randomNum[0], randomNum[1], randomNum[2], randomNum[3], randomNum[4], randomNum[5]);
    Lottery *head = NULL;
    Lottery lottery = {0};
    Lottery *current = (Lottery *)malloc(sizeof(Lottery));
    if (current == NULL)
    {
        printf("============================\n");
        printf("|  �ڴ����ʧ�ܣ�          |\n");
        printf("============================\n");
        return;
    }
    current->next = NULL;
    FILE *file_read = fopen("lottery3.txt", "r");
    if (file_read == NULL)
    {
        printf("============================\n");
        printf("|  ���ӷ�����ʧ�ܣ�        |\n");
        printf("============================\n");
        return;
    }
    while (fscanf(file_read, "��Ʊid��%s  �����û���%s  �ںţ�%s  ��Ʊ���ͣ�%d  �û����룺%s  �н����룺%s  �Ƿ񿪽���%d  �Ƿ��н���%d  �������ڣ�%s  �������ڣ�%s\n",
                  lottery.tid, lottery.uid, lottery.did, &lottery.category, lottery.usernumber, lottery.winnumber,
                  &lottery.draw, &lottery.win, lottery.buydate, lottery.windate) != EOF)
    {
        if (head == NULL)
        {
            head = current;
        }
        else
        {
            current->next = (Lottery *)malloc(sizeof(Lottery));
            if (current == NULL)
            {
                printf("============================\n");
                printf("|  �ڴ����ʧ�ܣ�          |\n");
                printf("============================\n");
                return;
            }
            current = current->next;
        }
        strcpy(current->tid, lottery.tid);
        strcpy(current->uid, lottery.uid);
        strcpy(current->did, lottery.did);
        current->category = lottery.category;
        strcpy(current->usernumber, lottery.usernumber);
        strcpy(current->winnumber, lottery.winnumber);
        current->draw = lottery.draw;
        current->win = lottery.win;
        strcpy(current->buydate, lottery.buydate);
        strcpy(current->windate, lottery.windate);
        current->next = NULL;
    }
    fclose(file_read);
    current = head;
    while (current != NULL)
    {
        InwinDate(current);
        current->draw = 1;
        strcpy(current->winnumber, randomStr);
        Prize(current, randomNum, 12);
        current = current->next;
    }
    FILE *file_write = fopen("lottery3.txt", "w");
    if (file_write == NULL)
    {
        printf("============================\n");
        printf("|  ���ӷ�����ʧ�ܣ�        |\n");
        printf("============================\n");
        return;
    }
    fclose(file_write);
    file_write = fopen("history.txt", "a");
    if (file_write == NULL)
    {
        printf("============================\n");
        printf("|  ���ӷ�����ʧ�ܣ�        |\n");
        printf("============================\n");
        return;
    }
    current = head;
    while (current != NULL)
    {
        fprintf(file_write, "��Ʊid��%s  �����û���%s  �ںţ�%s  ��Ʊ���ͣ�%d  �û����룺%s  �н����룺%s  �Ƿ񿪽���%d  �Ƿ��н���%d  �������ڣ�%s  �������ڣ�%s\n",
                current->tid, current->uid, current->did, current->category, current->usernumber, current->winnumber,
                current->draw, current->win, current->buydate, current->windate);
        current = current->next;
    }
    fclose(file_write);
    current = head;
    while (current != NULL)
    {
        Lottery *toFree = current;
        current = current->next;
        free(toFree);
    }
    head = NULL;
    printf("============================\n");
    printf("|  ����������            |\n");
    printf("============================\n");
}
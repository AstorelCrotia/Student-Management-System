#include "head.h"

void menu_sign(){
    char *address ="menu/wolcame.txt";
	menu_open(address);
}
void menu_user1(){
    char *address ="menu/menu_user1.txt";
	menu_open(address);
}
void menu_user2(){
    char *address ="menu/menu_user2.txt";
	menu_open(address);
}
void menu_user3()
{
	char *address ="menu/menu_user3.txt";
	menu_open(address);
}
void menu_admin1(){
    char *address ="menu/menuadmin1.txt";
	menu_open(address);
}
void menu_admin2()
{
	char *address ="menu/menuadmin2.txt";
	menu_open(address);
}
void menu_admin3()
{
	char *address ="menu/menuadmin3.txt";
	menu_open(address);
}
void menu_open(char *address)
{
	FILE *fp;
	if((fp = fopen(address,"rt"))==NULL)
	{
		printf("���ļ�ʧ�ܣ�");
		exit(0);
	}
	while(!feof(fp))
	{
		printf("%c",fgetc(fp));
	}
	fclose(fp);
	printf("\n��ѡ��-->");
}
#include "head.h"

Id_t *getIssue_txt(){
    Id_t *head,*p,*temp;
    head=malloc(sizeof(Id_t));
    if(head==NULL){
        printf("�����ڴ�ʧ�ܣ�\n");
        exit(0);
    }
    p=head;
    head->next=NULL;
    FILE *fp=fopen("issue.txt","rb");
    if(fp==NULL){
        printf("���ӷ�����ʧ�ܣ�");
        exit(0);
    }
    while(1){
        temp=malloc(sizeof(Id_t));
        if(fscanf(fp,"�����ںţ�%s ��Ʊ���ۣ�%d ����״̬��%d �����۳�������%d �����ܽ�%d �н����룺%d %d %d %d %d %d %d\n",temp->issueID,&temp->unitPrice,&temp->lotteryState,&temp->totalSales,&temp->currentPrizePool,&temp->winningNumbers[0],&temp->winningNumbers[1],&temp->winningNumbers[2],&temp->winningNumbers[3],&temp->winningNumbers[4],&temp->winningNumbers[5],&temp->winningNumbers[6])==EOF)break;
        p->next=temp;
        p=temp;
        p->next=NULL;
    }
    fclose(fp);
    free(temp);
    temp=NULL;
    return head;
}
void putIssue_txt(Id_t *head){
    FILE *fp = fopen("issue.txt", "wb");
    if (fp == NULL) {
        printf("�޷����ļ���");
        exit(0);
    }
    Id_t *temp=head->next;
    while(temp!=NULL){
        fprintf(fp, "�����ںţ�%s ��Ʊ���ۣ�%d ����״̬��%d �����۳�������%d �����ܽ�%d �н����룺%d %d %d %d %d %d %d\n",temp->issueID,temp->unitPrice,temp->lotteryState,temp->totalSales,temp->currentPrizePool,temp->winningNumbers[0],temp->winningNumbers[1],temp->winningNumbers[2],temp->winningNumbers[3],temp->winningNumbers[4],temp->winningNumbers[5],temp->winningNumbers[6]);
        temp=temp->next;
    }
    fclose(fp);
}
void Issue_lottery(Id_t *head){
    Id_t *temp=head->next,*p=head;
    while(temp!=NULL){
        if(temp->lotteryState!=1){
            printf("�ѷ��۵Ĳ�Ʊ��δ���������ɷ�����һ�ڲ�Ʊ��\n");
            return;
        }else{
            temp=temp->next;
            p=p->next;
        }
    }
    Id_t *newissue=malloc(sizeof(Id_t));
    getData(newissue->issueID);
    printf("�������Ʊ���ۣ�");
    scanf("%d",&newissue->unitPrice);
    newissue->lotteryState=0;
    rand_winNumber(newissue);
    newissue->totalSales=0;
    if(p==head){
        printf("���������ý��ص��ܽ�");
        scanf("%d",&newissue->currentPrizePool);
    }else{
        printf("���ڽ������%d,�������������Ľ����ȣ�",p->currentPrizePool);
        int money=0;
        scanf("%d",&money);
        newissue->currentPrizePool=p->currentPrizePool+money;
    }
    p->next=newissue;
    p=newissue;
    p->next=NULL;
    putIssue_txt(head);
    printf("���гɹ���\n");
    printf("�����ںţ�%s ��Ʊ���ۣ�%d ����״̬��%d �����ܽ�%d\n",p->issueID,p->unitPrice,p->lotteryState,p->currentPrizePool);
    newissue=NULL;
    free(newissue);
    delay(3);
}
void rand_winNumber(Id_t *head){
    srand(time(0));
    for(int i=0;i<7;i++){
        if(i<5){
            head->winningNumbers[i]=rand()%32;
        }else{
            head->winningNumbers[i]=rand()%10;
        }
    }
}
void Draw_lottery(USER *users,Id_t *issue,Td_t *ticket,Td_t *pwinner){
    Id_t *temp=issue;
    while(temp->next!=NULL){
        temp=temp->next;
    }
    if(temp==issue){
          printf("��δ���۲�Ʊ������ʧ�ܣ�\n");
          return;
    }
    temp->lotteryState=1;
    printf("�����ɹ���\n");
    paylevel(users,issue,ticket);
    payout(users,issue,ticket);
    putIssue_txt(issue);
    putticket_txt(ticket);
    putUser_txt(users);
    putprevwinner_txt(ticket);
    Td_t *temp1=getprvewinner_txt();
    pwinner->next=temp1->next;
}
void paylevel(USER *users,Id_t *issue,Td_t *ticket){
    Id_t *temp1=issue;
    Td_t *temp2=ticket->next;
    int count1=0;
    int count2=0;
    while(temp1->next!=NULL){
        temp1=temp1->next;
    }
    while(temp2!=NULL){
        if(!strcmp(temp2->issueID,temp1->issueID)){
            for(int i=0;i<7;i++){
                if(i<=5){
                    if(temp1->winningNumbers[i]==temp2->Number[i]){
                        count1++;
                    }
                }else{
                    if(temp1->winningNumbers[i]==temp2->Number[i]){
                        count2++;
                    }
                }
            }
            if(count1==6&&count2==1){
                temp2->lotteryState=1;
            }else if(count1<6&&count1>=3&&count2==1){
                temp2->lotteryState=2;
            }else if(count1>=1&&count1<3&&count2==1){
                temp2->lotteryState=3;
            }else{
                temp2->lotteryState=5;
            }
        }
        temp2=temp2->next;
    }
}
void payout(USER *users,Id_t *issue,Td_t *ticket){
    USER *temp1=users->next;
    Td_t *temp2=ticket->next;
    Id_t *temp3=issue;
    while(temp3->next!=NULL){
        temp3=temp3->next;
    }
    while(temp2!=NULL){
        if(!strcmp(temp3->issueID,temp2->issueID)){
            while(temp1!=NULL){
                int money=0;
                if(!strcmp(temp1->name,temp2->name)&&temp2->state==0){
                    if(temp2->lotteryState==1){
                        money=300000*(temp2->betNumber);
                        temp1->userBalance+=money;
                    }else if(temp2->lotteryState==2){
                        money=100000*(temp2->betNumber);
                        temp1->userBalance+=money;
                    }else if(temp2->lotteryState==3){
                        money=30000*(temp2->betNumber);
                        temp1->userBalance+=money;
                    }else{
                        temp1->userBalance+=0;
                    }
                    temp2->jackPots=money;
                    temp3->currentPrizePool-=money;
                    temp2->state=1;
                    break;
                }
                temp1=temp1->next;
            }
        }
        temp1=temp1=users->next;
        temp2=temp2->next;
    }
}
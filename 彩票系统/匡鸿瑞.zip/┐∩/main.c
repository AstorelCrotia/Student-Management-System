#include "head.h"

int main(){
    USER *U=getUser_txt();
    Id_t *I=getIssue_txt();
    Td_t *T=getticket_txt();
    Td_t *Pwinner=getprvewinner_txt();
    while(1){
        menu_sign();
        int select=0;
        scanf("%d",&select);
        switch (select)
        {
        case 1:admin_login(U,I,T,Pwinner);
            break;
        case 2:user_login(U,I,T,Pwinner);
            break;
        case 3:registerUser(U);
            break;
        case 0:printf("��ӭ�´ι��٣�\n");
            exit(0);
            break;
        default:
            break;
        }
    }
}